Soren Marius
002456139
Marius@chapman.edu
CPSC-230-02
Assignment 4
Source files:

WordCount.py

(not sure if these count)
hp.text
counts.txt

No known errors

No references used (other than Dr. Stevens)