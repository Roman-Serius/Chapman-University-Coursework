Soren Marius
002456139
Marius@chapman.edu
CPSC-230-02
Assignment 2
Source files:
Adventure.py

No None Errors at this time

Notes:
I realize now a lot of my functions could've worked better using a return statement.
    However, at this point that's too much work to be worth it.
I recommend playing through without looking at the code first, but if you need to work through more sections
    to make sure it works, you can also comment out the openining section and set sleep(0) under print_slow
I hope you enjoy!

Sources:
I used a Discord server "The coding den" when things were broken and I didn't know how to fix them. 
    (Noone wrote code for me just gave me options)
    The only big change to come of the sever was using a function argument in my definitions.
Slow Print: https://forums.raspberrypi.com/viewtopic.php?t=136516#:~:text=The%20basic%20procedure%20is%20simple,throwing%20some%20sleep%20in%20between.&text=And%20then%20I%20got%20nothing,me%20(using%20Python%203).
Making Sleep work printing across one line (using flush=True): Joe Ellis (my housemate)