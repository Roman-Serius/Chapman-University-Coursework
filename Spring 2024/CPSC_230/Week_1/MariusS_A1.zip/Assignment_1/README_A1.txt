Soren Marius
002456139
Marius@chapman.edu
CPSC-230-02
Assignment 1