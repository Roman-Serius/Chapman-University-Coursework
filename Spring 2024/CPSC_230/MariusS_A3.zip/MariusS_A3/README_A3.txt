Soren Marius
002456139
Marius@chapman.edu
CPSC-230-02
Assignment 3

Source files:
Stats.py
Complement.py

No known errors

No used references