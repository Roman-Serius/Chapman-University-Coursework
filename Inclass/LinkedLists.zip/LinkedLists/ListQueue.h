#ifndef LIST_QUEUE_H
#define LIST_QUEUE_H

#include "DblList.h"

template<typename T>
class Queue{
    public:
    Queue();
    virtual ~Queue();
    int getSize();
    bool isEmpty();
    T pop();
    private:
    DblList List;
    T add(T data);



    
}
template<typename T>
Queue::Queue(){
    List = DblList();



}
template<typename T>
Queue::pop(){
    List.removefront();


}
template<typename T>
Queue::add(T data){
    List.addBack(data);
}


#endif