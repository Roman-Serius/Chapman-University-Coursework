#ifndef LIST_STACK_H
#define LIST_STACK_H

template<typename T>
class Stack{
    public:



}


#endif