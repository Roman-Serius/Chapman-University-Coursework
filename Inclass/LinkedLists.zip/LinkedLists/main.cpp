#include "ListQueue.h"

int maint(){
    Queue queue = new Queue();
    
}